#ifndef BLOC_HPP
#define BLOC_HPP
#include <unordered_map>
#include <vector>
#include <string>
using namespace std; 
typedef unordered_map<string, int> t_table;
typedef pair<string, int> t_val;

class bloc{
    public:
    //constructeur
    bloc();

    //destructeur
    ~bloc();

    //afficher une variable
    void afficher(string cle);

    //ajouter une variable 
    void affectation(string cle, int valeur);

    //incrementer une variable
    void incrementer(string cle);

    //decrementer une variable
    void decrementer(string cle, string indent);
    
    //reinitialiser la table des variables déclarees (utilise seulement lors de l'ouverture d'un bloc)
    void initVarDeclar();

    //afficher les variables a la fermeture du bloc
    void afficherFermeture(string indent);

   

    private:
    t_table contenu; 
    vector<t_val> varDeclare;

    
};







#endif