#ifndef STRUCTBLOC_HPP
#define STRUCTBLOC_HPP
#include "pile.hpp"
using namespace std;

//PILE DE BLOC
class structBloc{
    public:
    //constructeur
    structBloc();

    //destructeur
    ~structBloc();

    //ajout bloc
    void ouvrirBloc();

    //retrait bloc
    void fermerBloc(string indent);

    //bloc en cours
    void affectation(string nom, int valeur);

    //affichage valeur
    void afficherValeur(string cle, string indent);

    //incrementation valeur
    void incrementerValeur(string cle);

    //decrementation valeur
    void decrementerValeur(string cle, string indent);

    //est vide
    bool est_vide();




    private:
    pile pileBloc;
};










#endif