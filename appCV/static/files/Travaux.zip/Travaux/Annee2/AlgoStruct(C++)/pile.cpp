#include "pile.hpp"


//Constructeur
pile::pile()
{
}

//Destructeur
pile::~pile()
{
}

//retourne le nombre d'élément de la pile
int pile::taille() {
    return V.size();
}

//Retourne l’élément au sommet d’une pile P non vide
bloc & pile::sommet() 
{
    return V.back();
}

//Ajoute un élément e au sommet de P
void pile::empiler(const bloc & b){
    V.push_back(b);
}

//retire le sommet d'une pile non vide
void pile::depiler(){
    V.pop_back();
}

// retourne vrai si P est vide, faux sinon
bool pile::est_vide() 
{
    return (V.empty());
}