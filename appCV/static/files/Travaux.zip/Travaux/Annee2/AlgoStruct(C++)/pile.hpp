#ifndef PILE_HPP
#define PILE_HPP
#include "bloc.hpp"
#include <iostream>

typedef int TELEM;

class pile {
public: 
    //Constructeur
    pile();

    //Destructeur
    ~pile();

    //retourne le nombre d'élément de la pile
    int taille() ;
    
    //Retourne l’élément au sommet d’une  non vide
    bloc & sommet() ;

    //Ajoute un élément e au sommet de P
    void  empiler(const bloc & b);

    //retire le sommet d'une pile non vide
    void depiler();

    // retourne vrai si P est vide, faux sinon
    bool est_vide() ;
    
    private:
    std::vector<bloc> V;
};

std::ostream& operator<<(std::ostream& os, pile& l);

#endif