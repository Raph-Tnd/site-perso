#include "structBloc.hpp"

using namespace std;


structBloc::structBloc(){
    pileBloc.empiler(bloc());
}

structBloc::~structBloc(){


}

void structBloc::ouvrirBloc(){
    pileBloc.empiler(pileBloc.sommet());
    pileBloc.sommet().initVarDeclar();
}

void structBloc::fermerBloc(string indent){
    pileBloc.sommet().afficherFermeture(indent);
    pileBloc.depiler();

}

void structBloc::affectation(string nom, int valeur){
    pileBloc.sommet().affectation(nom,valeur);
}

void structBloc::afficherValeur(string cle, string indent){
    cout << indent;
    pileBloc.sommet().afficher(cle);
}

void structBloc::incrementerValeur(string cle){
    pileBloc.sommet().incrementer(cle);
}

void structBloc::decrementerValeur(string cle, string indent){
    pileBloc.sommet().decrementer(cle, indent);
}

bool structBloc::est_vide(){
    return pileBloc.est_vide();
}

