#include <unordered_map>
#include <iostream>
#include "bloc.hpp"
using namespace std;  
    //constructeur
    bloc::bloc(){

    }

    //destructeur
    bloc::~bloc(){

    }

    //afficher une variable
    void bloc::afficher(string cle){
        auto it = contenu.find(cle);
        if( it != contenu.end()){
            cout << cle << " = " << it -> second <<endl;
        }else{
            cout << "error : "<< cle << " not found!"<<endl;
        }
    }

     //ajouter une variable / utiliser dans la modif
    void bloc::affectation(string nom, int valeur){
        contenu[nom] = valeur;
        t_val temp(nom,valeur);
        varDeclare.push_back(temp);
    }

    //incrementer une variable
    void bloc::incrementer(string cle){
        auto it = contenu.find(cle);
        if( it != contenu.end()){
            int res = (it ->second) +1;
            affectation(cle,res);
        }else{
            cout << "error : "<< cle << " not found!"<<endl;
        }
    }

    //decrementer une variable 
    void bloc::decrementer(string cle, string indent){
        auto it = contenu.find(cle);
        if( it != contenu.end()){
            if (it ->second > 0){
                int res = (it ->second) -1;
                affectation(cle,res);
            }else{
                cout << indent << "error : "<< cle << " = 0"<<endl;
            }
            
        }else{
            cout << "error : "<< cle << " not found!"<<endl;
        }
    }

    //reinitialiser la table des variables déclarees (utilise seulement lors de l'ouverture d'un bloc)
    void bloc::initVarDeclar(){
        varDeclare.clear();
    }

    //afficher les variables a la fermeture du bloc
    void bloc::afficherFermeture(string indent){
        cout << indent <<"Var. declaree dans bloc :"<<endl;
        auto it = varDeclare.begin();
        while (it != varDeclare.end()){
            cout << indent << (*it).first << " = " <<(*it).second <<endl;
            it++;
        }
        cout <<endl;
    }

   


    
