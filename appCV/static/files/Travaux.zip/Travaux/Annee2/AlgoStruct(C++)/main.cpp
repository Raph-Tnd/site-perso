#include <cstdlib>
#include <iostream>
#include <string>
#include "parser.hpp"
#include "structBloc.hpp"

using namespace std;
int nbBloc = 1;

int main(void)
{
  parser a_parser;
  string line;
  TOKEN tok;
  structBloc sdc;
  string indent = "   ";
  string indentPrint = indent + "                           | ";
  int nbLignes = 1;

  cout <<nbLignes << ". {"<<endl;
  while(nbBloc > 0){
    nbLignes++;
    cout <<nbLignes << ". " <<indent;
    //cout << "Write one line of an asd2 program:" << endl;
    getline(cin,line);
    
    tok = a_parser.parse(line);

    //cout << "Result of parsing:" << endl;

    switch(tok)
    {
      case TOKEN_OPEN:
      {
        indent+= "   ";
        nbBloc++;
        sdc.ouvrirBloc();
        break;
      }
      case TOKEN_CLOSE:
      {
        nbBloc--;
        sdc.fermerBloc(indentPrint);
        indent.resize(indent.size()-3);
        break;
      }
      case TOKEN_VAR:
      {
        sdc.affectation(a_parser.var(), a_parser.value());
        break;
      }
      case TOKEN_PRINT:
      {
        sdc.afficherValeur(a_parser.var(), indentPrint);
        break;
      }
      case TOKEN_ERROR:
      {
        cout <<indentPrint << a_parser.error() <<endl;
        break;
      }
      case TOKEN_INCRE:
      {
        sdc.incrementerValeur(a_parser.var());
        break;
      }

      case TOKEN_DECRE:
      {
        sdc.decrementerValeur(a_parser.var(), indentPrint);
        break;
      }
    }
  }
  
  return EXIT_SUCCESS;
}
