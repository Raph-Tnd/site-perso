
public class Salarie {
	private String nom;
	private double poids;	//kg
	private double salaire;	//euros//heure
	private double chargeUtile;	//poids/8
	
	public Salarie(String nom, double poids, double salaire) {
		this.nom = nom;
		this.poids = poids;
		this.salaire = salaire;	//eur/h
		this.chargeUtile = poids/8;
	}
	
	//GETTERS
	
	public String getNom() {
		return nom;
	}
	
	public double getSalaire() {
		return salaire;
	}
	
	public double getChargeUtile() {
		return chargeUtile;
	}
	
	public double getPoids() {
		return poids;
	}
}
