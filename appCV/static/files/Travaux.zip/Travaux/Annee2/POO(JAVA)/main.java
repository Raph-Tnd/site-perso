import java.util.Scanner;

public class main{

	public static void main(String[] args) {
	
		Salarie Louise = new Salarie("Louise", 55, 7.4 );
		Salarie Alfred = new Salarie("Alfred", 80, 7.2 );
		Salarie Camille = new Salarie("Camille", 55, 7.5 );
		Salarie Pierre = new Salarie("Pierre", 55, 7.2 );
		
		Velo Velov = new Velo("Velov", 450 );
		Velo Bicloo = new Velo("Bicloo", 500 );
		
		Scooter Yamama = new Scooter("Yamama", 300, 3500, 50, 7.5);
		Scooter Vespo = new Scooter("Vespo", 125, 2500, 30, 5.5);
		Scooter Piagi = new Scooter("Piagi", 150, 2000, 35, 6);
		
		Scooter Dimitri = new Scooter("Dimitri", 300, 3500, 50 ,7.5);
		Vehicule Raph = Dimitri;
		
		
		Entreprise UberEats = new Entreprise();
		//ajout donnée
		
		UberEats.addSalarie(Louise);
		UberEats.addSalarie(Alfred);
		UberEats.addSalarie(Camille);
		UberEats.addSalarie(Pierre);
		
		UberEats.addVehicule(Velov);
		UberEats.addVehicule(Bicloo);
		UberEats.addVehicule(Yamama);
		UberEats.addVehicule(Vespo);
		UberEats.addVehicule(Piagi);
		UberEats.addVehicule(Dimitri);
		UberEats.addVehicule(Raph);
		
		
		// POUR LE TEST DU PDF, IL FAUT AJOUTER DANS L'INTERFACE LE REPAS DE 5 KG SUR LA DISTANCE DE 3 KM
		Interface inter = new Interface(UberEats);
		Scanner scan = new Scanner(System.in);
		
		while (inter.getStartAgain() == true) {		
			inter.tableauBord(scan);
		}
		scan.close();
		
		
		
	}

}
