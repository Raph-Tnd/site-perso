import java.util.*;

public class Entreprise {
	private ArrayList<Vehicule> tabVehicule;
	private ArrayList<Salarie> tabSalarie;
	private ArrayList<Course> tabCourse;
	
	public Entreprise() {
		this.tabVehicule = new ArrayList<Vehicule>();
		this.tabSalarie = new ArrayList<Salarie>();
		this.tabCourse = new ArrayList<Course>();
	}
	
	public ArrayList<Course> getCourses(){
		return tabCourse;
	}
	
	public ArrayList<Salarie> getSalaries(){
		return tabSalarie;
	}
	public ArrayList<Vehicule> getVehicules(){
		return tabVehicule;
	}
	
/*----------------------Gestion TAB------------------- */	
	
		//VEHICULE
	public void addVehicule(Vehicule vehicule) {
		tabVehicule.add(vehicule);
	}
	
	public void removeVehicule(Vehicule vehicule) {
		for (int i = 0; i <tabVehicule.size(); i++) {
			if (tabVehicule.get(i).equals(vehicule)){
				tabVehicule.remove(i);
			}
		}
	}
	
	public void affichageVehicule() { // a impl�menter
		for(int i = 0; i < tabVehicule.size(); i++) {
			System.out.println(tabVehicule.get(i).getNom());
		}
	}
	
	
		//SALARIE
	public void addSalarie(Salarie salarie) {
		tabSalarie.add(salarie);
	}
	
	
	public void removeSalarie(Salarie salarie) {
		for (int i = 0; i <tabSalarie.size(); i++) {
			if (tabSalarie.get(i).equals(salarie)){
				tabSalarie.remove(i);
			}
		}
		
	}
	
	public void affichageSalarie() { // a impl�menter
		for(int i = 0; i < tabSalarie.size(); i++) {
			System.out.println(tabSalarie.get(i).getNom());
		}
	}
	
		//COURSE
	public void addCourse(Course course) {
		tabCourse.add(course);
	}
	
	
	public void removeCourse(Course course) {
		for (int i = 0; i <tabCourse.size(); i++) {
			if (tabCourse.get(i).equals(course)){
				tabCourse.remove(i);
			}
		}
		
	}

	
	public void affichageCourse() { 
		System.out.println(tabCourse.get(0).getPoids() + "kg sur "+ tabCourse.get(0).getDistance()+ "km :" );		//pour afficher le poids et la distance des courses a suivre
		int j = 1;
		for(Course c : tabCourse) {
			System.out.println("	" + j + "- " +   c.getSalarie().getNom() + " / " + c.getVehicule().getNom() + ", cout de la livraison : " + c.prixCourse() + " �");
		j++;
		}
		System.out.println(" ");
	}
	
/*-----------------------------------------------------------------------------------*/
	
	
	public void creerTouteCourse(double poids, double distance) {		//creer toutes les courses possibles pour le repas donn�e en parametres
		tabCourse.clear();
		for(Salarie s : tabSalarie) {
			for (Vehicule v : tabVehicule) {
				if (poids <= Math.max(s.getChargeUtile(),v.getCharge())) {	//verif poids
					if ((distance*2)/v.getVMoyenne() <=1) {		//verif temps course
						addCourse(new Course(poids, distance, s , v));
					}
				}
			}
		}
		System.out.println(" ");	//passer une ligne
	}
	
	
	//PRE: le tableau de course n'est pas vide
	//a utiliser apres creerTouteCourse
	public void calculOpti() {		
		ArrayList<Course> aux = new ArrayList<Course>();
		int j;
		for (Course c: tabCourse) {
			j = 0;
			while ( (c.testOpti(tabCourse.get(j)) == c) && (j < (tabCourse.size() -1)) ){		//permet de tester la course avec toute les autres sauf la derniere
				j++;
			}
			if (j == tabCourse.size() -1 ) {	//test avec la derniere
				if ( (c.testOpti(tabCourse.get(j)) ) == c) {
					aux.add(c);
				}
			}
		}
		tabCourse.clear();
		tabCourse.addAll(aux);
		if(tabCourse.isEmpty()) {
			System.out.println("Pas de course optimale, recreer les courses !!");
		}
	}
	
	public void moinsPolluante() {	//retourne les courses moins polluantes que toutes les autres
		int i;
		ArrayList<Course> aux= new ArrayList<Course>();
		for (Course c :tabCourse) {
			i = 0;
			while ( (c.moinsPolluante(tabCourse.get(i)) == c) && (i < (tabCourse.size() -1))) {
				i++;
				
			}
			if (i == (tabCourse.size() -1))  {
				if (c.moinsPolluante(tabCourse.get(i)) == c) {
						aux.add(c);
				}
			}
		}
		tabCourse.clear();
		tabCourse.addAll(aux);
		
	}
	
		
}
	
	
	

