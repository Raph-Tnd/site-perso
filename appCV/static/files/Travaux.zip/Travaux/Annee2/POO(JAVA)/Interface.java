import java.util.ArrayList;
import java.util.Scanner;

public class Interface {
	private Entreprise ent;
	private boolean startAgain ;
	private ArrayList<Course> cEnCours;	//gestion des courses en cours (salarie/vehicule)
	
	public Interface(Entreprise ent) {
		this.ent = ent;
		startAgain = true;
		cEnCours = new ArrayList<Course>();
	}
	
	public boolean getStartAgain() {
		return startAgain;
	}
	
	public void tableauBord(Scanner scan) {		//Interface principale
		System.out.println("Que voulez vous faire ? : (appuyer sur la touche correspondante)");
		System.out.println(" ");
		System.out.println("	1- Ajouter un nouveau repas ");
		System.out.println("	2- Afficher les courses pour le repas suivant (-> Courses optimales -> Moins polluantes)");
		System.out.println("	3- Choisir une course ");
		System.out.println("	4- Retour de course ");
		System.out.println("	5- Ajouter un salarie");
		System.out.println("	6- Ajouter un v�hicule");
		System.out.println(" 	7- Afficher les salari�s disponible");
		System.out.println(" 	8- Afficher les v�hicules disponible");
		System.out.println("	9- Arret");
		
		int res = scan.nextInt();
		
		if (res == 1) {
			ajouterRepas(scan);
		}
		
		if (res == 2) {
			affichageGeneralCourse(scan);
		}
		
		if (res == 3) {
			choixCourse(scan);
		}
		
		if (res == 4) {
			retourCourse(scan);
		}
		
		if (res == 5) {
			ajoutSalarie(scan);
		}
		
		if (res == 6) {
			choixVehicule(scan);
		}
		
		if (res == 7) {
			affichageSalarie();
		}
		
		if (res == 8) {
			affichageVehicule();
		}
		
		if (res == 9) {
			startAgain = false;
		}
		
	}
	
	public void affichageSalarie() {
		System.out.println("Ces salari�s sont disponibles : ");
		for (Salarie s : ent.getSalaries() ) {
			System.out.println("	- " + s.getNom());
		}
		System.out.println(" ");
		System.out.println("Ces salari�s sont en courses : ");
		for (Course c : cEnCours ) {
			System.out.println("  	- " + c.getSalarie().getNom());
		}
		System.out.println(" ");
	}
	
	public void affichageVehicule() {
		System.out.println("Ces v�hicules sont disponibles : ");
		for (Vehicule v : ent.getVehicules()) {
			System.out.println("	- " + v.getNom());
		}
		System.out.println(" ");
		System.out.println("Ces v�hicules sont en courses :");
		for (Course c : cEnCours) {
			System.out.println("	- " + c.getVehicule().getNom());
		}
		System.out.println(" ");
	}
	
	public void choixCourse(Scanner scan) {
		if (ent.getCourses().size() > 0) {
			System.out.println("Voici un rappel des courses disponibles  : ");
			ent.affichageCourse();
			System.out.println(" Donner le chiffre correspondant de a celle desirez  :");
			int num = scan.nextInt() -1;
			
			if ((num >= 0) && (num < ent.getCourses().size())) {
				cEnCours.add(ent.getCourses().get(num));
				ent.removeSalarie(ent.getCourses().get(num).getSalarie());
				ent.removeVehicule(ent.getCourses().get(num).getVehicule());
				
				System.out.println("Choix prix en compte.");
				
			}else {
				System.out.println("Le numero n'existe pas, recommencer ");
			}
		}else {
		System.out.println("Pas de courses disponibles.");
		}
		System.out.println(" ");
	}
	
	public void retourCourse(Scanner scan) {
		if (cEnCours.size() >0 ) {
			System.out.println("Rappel des courses en cours :");
			for (int i = 1 ; i <= cEnCours.size(); i++) {
				System.out.println("	 " + i + "- " + cEnCours.get(i-1).getSalarie().getNom() + " / " + cEnCours.get(i-1).getVehicule().getNom() + ", repas de " + cEnCours.get(i-1).getPoids() + " kg sur " + cEnCours.get(i-1).getDistance() + " km.");
			}
			System.out.println("Choisissez le numero correspondant a la course qui est fini");
			int num = scan.nextInt() -1;	//List commence a 0 et l'affichage commence a 1
			if (num >= 0) {
				ent.addSalarie(cEnCours.get(num).getSalarie());
				ent.addVehicule(cEnCours.get(num).getVehicule());
				cEnCours.remove(num);
				System.out.println("Retour prix en compte, retour du salarie et du vehicule.");
			}else {
				System.out.println("Cette course n'existe pas, retour au menu");
			}
		}else {
			System.out.println("Pas de courses en cours.");
		}
		System.out.println(" ");
	}
	
	public void ajouterRepas(Scanner scan) {
		System.out.println("Donner le poids du repas en kg : ");
		double poids = scan.nextDouble();
		System.out.println("Donner la distance de livraison du repas en km: ");
		double distance = scan.nextDouble();
		System.out.println("Attention cela supprimera le repas en cours, �tes vous s�res ? ( Ecrire Y si oui ) :");
		String sure  = scan.next();
		if (sure.equals("Y")) {
			ent.creerTouteCourse(poids, distance);
			System.out.println("Repas ajout�");
		}else {
			System.out.println("Retour au menu. ");
		}
		System.out.println(" ");
	}
	
	public void affichageGeneralCourse(Scanner scan) {
		if (ent.getCourses().size() == 0) {
			System.out.println("Pas de course possible. (Avez-vous ajoutez un repas a livrer ?) ");
		}else {
			ent.affichageCourse();
			System.out.println("Voulez voir les courses optimales ? (Y pour oui) ");
			String sure = scan.next();
			if (sure.equals("Y")) {
				affichageOpti(scan);
			}
		}
		System.out.println(" ");
	}
	
	public void affichageOpti(Scanner scan) {
		ent.calculOpti();
		ent.affichageCourse();
		if (ent.getCourses().size() == 0 ) {
			System.out.println("Pas de courses optimales disponible");	//extremement rare
		}else {
			System.out.println("Voulez vous voir les courses les moins polluantes ? (Y pour oui) ");
			String sure = scan.next();
			if (sure.equals("Y")) {
				affichageMoinsPolluantes();
			}
		}
		System.out.println(" ");
	}
	
	public void affichageMoinsPolluantes() {
		ent.moinsPolluante();
		ent.affichageCourse();	
		//impossible d'avoir aucune course moins polluante
		System.out.println(" ");
	}
	
	public void ajoutSalarie(Scanner scan) {
		
		System.out.println("Donner le nom du salari� : ");
		String nom = scan.next();
		
		System.out.println("Donner le poids du salari� ");
		double poids = scan.nextDouble();
		
		System.out.println("Donner le salaire du salari� : (eur/h)");
		double salaire = scan.nextDouble();
		
		
		int size = ent.getSalaries().size();
		ent.addSalarie(new Salarie(nom, poids, salaire));
		if (ent.getSalaries().size() > size) {
			System.out.println("Salari� ajout�");
		}else {
			System.out.println("Erreur recommencer");
		}
		
		System.out.println(" ");
	}
	
	public void choixVehicule(Scanner scan) {
		
		System.out.println("Quel type de vehicule voulez-vous ajoutez ? : (appuyer sur la touche correspondante)");
		System.out.println("	1- Velo");
		System.out.println("	2- Scooter");
		System.out.println("	Autre num�ro - Annuler");
		int res = scan.nextInt();
		
		if (res == 1) {
			ajoutVelo(scan);
		}
		if (res == 2) {
			ajoutScooter(scan);
		}
		System.out.println(" ");
	}
	
	public void ajoutVelo(Scanner scan) {
		
		System.out.println("Donner le nom du velo :");
		String nom = scan.next();
		
		System.out.println("Donner le prix d'achat du velo :");
		double pAchat = scan.nextDouble();
		
		
		int size = ent.getVehicules().size();
		ent.addVehicule(new Velo(nom, pAchat));
		
		if(ent.getVehicules().size() > size) {
			System.out.println("Velo ajout�");
		}else {
			System.out.println("Erreur, recommencer");
		}
		
		System.out.println(" ");
	}
	
	public void ajoutScooter(Scanner scan) {
		
		System.out.println("Donner le nom du scooter :");
		String nom = scan.next();
		
		System.out.println("Donner le cylindree du scooter :");
		double cylindree = scan.nextDouble();
		
		System.out.println("Donner le prix d'achat du scooter : ");
		double pAchat = scan.nextDouble();
		
		System.out.println("Donner la charge possible maximale du scooter");
		double charge = scan.nextDouble();
		
		System.out.println("Donner la consommation du scooter (en litre au 100km");
		double consommation = scan.nextDouble();
		
		
		int size = ent.getVehicules().size();
		ent.addVehicule(new Scooter (nom, cylindree, pAchat, charge, consommation));
		
		if (ent.getVehicules().size() > size) {
			System.out.println("Scooter ajout�");
		}else {
			System.out.println("Erreur, recommencer");
		}
		
		System.out.println(" ");
	}
}
