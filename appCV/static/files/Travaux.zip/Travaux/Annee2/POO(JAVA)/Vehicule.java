 
public abstract class  Vehicule {
	protected static double pEssence;
	private String nom;
	private double pAchat;	// euros	
	private double vMoyenne;	// km/h
	private double co2Emis;
	private double charge;
	private double cUtil;	// euro/km
	
	public Vehicule(String nom, double pAchat, double vMoyenne, double co2Emis, double charge, double cUtil) {
			this.pEssence = 1.45;
			this.nom = nom;
			this.pAchat = pAchat;
			this.vMoyenne = vMoyenne;
			this.co2Emis = co2Emis;
			this.charge = charge;
			this.cUtil = cUtil;
	}
	
	
		//GETTERS
	
	public String getNom() {
		return nom;
	}
	
	
	public double getPAchat() {
		return pAchat;
	}
	
	public double getCUtil() {
		return cUtil;
	}
	
	public double getCharge() {
		return charge;
	}
	
	public double getCo2() {
		return co2Emis;
	}
	
	public double getVMoyenne() {
		return vMoyenne;
	}
}
