
public class Course {
	private double poids;
	private double distance;
	private Salarie salarie;
	private Vehicule vehicule;
	
	public Course(double poids, double distance, Salarie salarie, Vehicule vehicule) {
		this.poids = poids;
		this.distance = distance;
		this.salarie = salarie;
		this.vehicule = vehicule;
	}
	
		//GETTERS
	
	public double getPoids() {
		return poids;
	}
	
	public double getDistance() {
		return distance;
	}
	
	public Salarie getSalarie() {
		return salarie;
	}
	
	public Vehicule getVehicule() {
		return vehicule;
	}
	
	public double tempsCourse() {
		return (distance*2 / (vehicule.getVMoyenne()));
	}
	
	public double prixCourse() {
		return( (salarie.getSalaire() *tempsCourse()) + (vehicule.getCUtil()*distance*2) );
	}
	
 
	public Course testOpti(Course a) {		// return la meilleure des deux courses
				double thisC = vehicule.getCo2();
				double c2 = a.getVehicule().getCo2();
				double thisP = this.prixCourse();
				double p2 = a.prixCourse();	
				
				if (((thisC > c2) && (thisP > p2)) || ((thisC > c2) && (thisP ==  p2)) || ((thisC == c2) && (thisP > p2))) {
					return a;
				}else {
					return this;
				}		
	}
	
	public Course moinsPolluante(Course c) {	//return la course la moins polluantes des deux 
		if (this.getVehicule().getCo2() <= c.getVehicule().getCo2()) {
			return this;
		}else {
			return c;
		}
	}
}
