
public class Velo extends Vehicule{
	
	public Velo(String nom, double pAchat) {
		super(nom, pAchat, 15, 0, 0, pAchat/30000);
	}
}
