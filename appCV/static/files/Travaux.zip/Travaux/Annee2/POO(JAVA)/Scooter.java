
public class Scooter extends Vehicule{
	private double cylindree;	//cm3
	private double consommation;	// l/100km
	
	public Scooter(String nom, double cylindree, double pAchat, double charge, double consommation) {
		super(nom, pAchat, 30 + (cylindree/50), cylindree/4, charge, (pAchat/20000) + (consommation/100)*pEssence);
		this.cylindree = cylindree;
		this.consommation = consommation;
	}
	
	
		//GETTERS
	
	public double getCylindree() {
		return cylindree;
	}
	
	public double getConsommation() {
		return consommation;
	}
}
