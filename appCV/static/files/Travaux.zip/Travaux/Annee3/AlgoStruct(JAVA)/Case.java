
public class Case {
	private int valeur;
	private int couleur; //0 vide, 1 rouge, 2 bleu
	private boolean colorHover;
	private int x;
	private int y;
	
	public Case(int n, int c, int ligne, int colonne) {
		this.valeur = n;
		this.couleur = c;
		this.x = ligne;
		this.y = colonne;
		this.colorHover = false;

	}
	
	//retourne la valeur de la case
	public int getValeur() {	
		return this.valeur;
	}
	
	//retourne la couleur de la case
	public int getCouleur() {	
		return this.couleur;
	}
	
	//retourne la coordonne horizontal de la case
	public int getX() {			
		return x;
	}
	
	//retourne la coordonne vertical de la case	
	public int getY() {		
		return y;
	}
	
	//changer la couleur 
	public void changerCouleur(int c) {		
		this.couleur = c;
	}
	
	// (utile pour afficherComposante)
	public boolean getHover() {		
		return colorHover;
	}
	
	//passer en true ou false
	public void hover() {	
		if (colorHover) {
			colorHover = false;
		}else {
			colorHover = true;
		}
	}
	
}

