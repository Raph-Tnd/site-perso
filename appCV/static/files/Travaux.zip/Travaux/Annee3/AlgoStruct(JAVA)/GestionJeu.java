import java.io.FileNotFoundException;


public class GestionJeu  {
	//J2 DEVIENT ORDINATEUR
	Fenetre jouer = new Fenetre();
	
	public void jouerDeuxHumains() throws FileNotFoundException {
		jouer.changeOrdi(false);
	}
	
	public void jouerOrdiHumain() throws FileNotFoundException {
		jouer.changeOrdi(true);
		if (Fenetre.PLAYER == 2){
			if(!choixCaseAdj()) {	//si pas de case coche
				choixCase();
			}
		}
	}
	

	//on choisit une des cases avec la valeur la plus haute
	public void choixCase() {
		Case temp = new Case(0,0,0,0);
		for (int i = 0 ; i <= Fenetre.tabPrincipal.getTaille()-1; i ++) {
			for (int j = 0; j <= Fenetre.tabPrincipal.getTaille()-1; j ++) {
				if(Fenetre.tabPrincipal.getTab()[i][j].getUnion().getRepresentant().getCouleur() == 0) {
					if(Fenetre.tabPrincipal.getTab()[i][j].getUnion().getRepresentant().getValeur() > temp.getValeur()) {
						temp = Fenetre.tabPrincipal.getTab()[i][j].getUnion().getRepresentant();
					}
				}
			}
		}
		if(!(temp.getValeur() == 0)) {
			simulerClique(temp.getX(), temp.getY());
		}
	}
	
	//on choisit une case adjacente au case de meme couleur avec valeur haute
	public boolean choixCaseAdj() {		//renvoie false si il n'y pas de case adjacente donc pas de simulation de clique
		Case res = new Case(0,0,0,0);
		Case temp = new Case(0,0,0,0);
		//pour chaque case de couleur rouge, on ajoute les cases blanches adjacentes dans un tableau
		for (UnionFind f : Fenetre.tabPrincipal.getJ2()) {		//pour les peres
			if(f.getRepresentant().getX() > 0) {
				//si case a gauche blanche
				temp = Fenetre.tabPrincipal.getTab()[f.getRepresentant().getX()-1][f.getRepresentant().getY()].getUnion().getRepresentant();
				if(temp.getCouleur() == 0) {
					if(temp.getValeur() > res.getValeur()) {
						res = temp;
					}
				}
			}
			if(f.getRepresentant().getY() > 0) {
				temp = Fenetre.tabPrincipal.getTab()[f.getRepresentant().getX()][f.getRepresentant().getY()-1].getUnion().getRepresentant();
				if(temp.getCouleur() == 0) {
					if(temp.getValeur() > res.getValeur()) {
						res = temp;
					}
				}
				
			}
			if(f.getRepresentant().getX() < Fenetre.tabPrincipal.getTaille()-1) {
				temp = Fenetre.tabPrincipal.getTab()[f.getRepresentant().getX()+1][f.getRepresentant().getY()].getUnion().getRepresentant();
				if(temp.getCouleur() == 0) {
					if(temp.getValeur() > res.getValeur()) {
						res = temp;
					}
				}
				
			}
			if(f.getRepresentant().getY() < Fenetre.tabPrincipal.getTaille()-1) {
				temp = Fenetre.tabPrincipal.getTab()[f.getRepresentant().getX()][f.getRepresentant().getY()+1].getUnion().getRepresentant();
				if(temp.getCouleur() == 0) {
					if(temp.getValeur() > res.getValeur()) {
						res = temp;
					}
				}
			}
			
			for (UnionFind fbis: f.getFils()) {		//pour les fils
				if(fbis.getRepresentant().getX() > 0) {
					//si case a gauche blanche
					temp = Fenetre.tabPrincipal.getTab()[fbis.getRepresentant().getX()-1][fbis.getRepresentant().getY()].getUnion().getRepresentant();
					if(temp.getCouleur() == 0) {
						if(temp.getValeur() > res.getValeur()) {
							res = temp;
						}
					}
				}
				if(fbis.getRepresentant().getY() > 0) {
					temp = Fenetre.tabPrincipal.getTab()[fbis.getRepresentant().getX()][fbis.getRepresentant().getY()-1].getUnion().getRepresentant();
					if(temp.getCouleur() == 0) {
						if(temp.getValeur() > res.getValeur()) {
							res = temp;
						}
					}
					
				}
				if(fbis.getRepresentant().getX() < Fenetre.tabPrincipal.getTaille()-1) {
					temp = Fenetre.tabPrincipal.getTab()[fbis.getRepresentant().getX()+1][fbis.getRepresentant().getY()].getUnion().getRepresentant();
					if(temp.getCouleur() == 0) {
						if(temp.getValeur() > res.getValeur()) {
							res = temp;
						}
					}
				}
				if(fbis.getRepresentant().getY() < Fenetre.tabPrincipal.getTaille()-1) {
					temp = Fenetre.tabPrincipal.getTab()[fbis.getRepresentant().getX()][fbis.getRepresentant().getY()+1].getUnion().getRepresentant();
					if(temp.getCouleur() == 0) {
						if(temp.getValeur() > res.getValeur()) {
							res = temp;
						}
					}
				}
			}
		}
		if (res.getValeur() == 0) {
			return false;
		}else {
			simulerClique(res.getX(),res.getY());
			return true;
		}
	}
	
	public void simulerClique(int x, int y ) {	//c'est tjrs pour le j2
		Fenetre.tabPrincipal.colorerCase(x, y, Fenetre.PLAYER);
		Fenetre.tabPrincipal.refreshTabJoueur();
		Fenetre.PLAYER = 1;
		this.jouer.changeScore();
		Fenetre.tabPrincipal.tourJoue();
	}
}
