import java.io.*;
import java.util.*;

public class ReadFile {
		private Scanner scan;
		private File file;
		
		public ReadFile(File f) {
			this.file = f;
		}
		
		public void remplirGrilleFichier() throws FileNotFoundException{
			try {
				scan = new Scanner(file);
			}catch (FileNotFoundException fe) {
				fe.printStackTrace();
			}
			
			int nbTour = 1;
			int taille = scan.nextInt();
			int valMax = scan.nextInt();
			int temp;
			Fenetre.tabPrincipal = new Tableau(taille,valMax);
			
			//construction des cases sans les couleurs;
			for (int i = 0; i <= taille-1; i ++) {
				for (int j = 0; j <= taille-1; j++) {
					//ici temp = score
					temp = scan.nextInt();
					if(temp >= 1 && temp <= valMax) {	//on verifie 1 < int < k
						Fenetre.tabPrincipal.getTab()[i][j] = new Bouton(new UnionFind(new Case(temp, 0, i, j)));
					}
				}
				scan.nextLine();		// apres n int on passe a la ligne suivante
			}
			//affectation des couleurs + union
			for (int i = 0; i <= taille-1; i ++) {
				for (int j = 0; j <= taille-1; j++) {
					//ici temp = couleur
					temp = scan.nextInt();
					if(temp >= 0 && temp <= 2) {		
						if (temp != 0) {
							//lorsqu'une case est de couleur
							//System.out.println(Fenetre.tabPrincipal.getTab()[i][j].getAlreadyPressed());
							//System.out.println(Fenetre.tabPrincipal.getTab()[i][j].getAlreadyPressed());
							Fenetre.tabPrincipal.colorerCase(i, j, temp);
							/*Fenetre.tabPrincipal.getTab()[i][j].getUnion().getRepresentant().changerCouleur(temp);
							Fenetre.tabPrincipal.unirCase(i, j, temp);*/
							System.out.println("temp = " +temp);
							System.out.println(" ");
							nbTour++;
						}
						
					}
				}
				scan.nextLine();
			}
			if (nbTour % 2 == 0) { //si tour du joueur 2
				
				Fenetre.PLAYER = 2;
			}
			Fenetre.tabPrincipal.refreshTabJoueur();
			Fenetre.tabPrincipal.changerNbTour(nbTour);
			
	}
}
