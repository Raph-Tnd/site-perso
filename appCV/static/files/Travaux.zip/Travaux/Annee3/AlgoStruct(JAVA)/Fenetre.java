import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import javax.swing.*;

public class Fenetre extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static int PLAYER = 1;
	//le tableau qui sera utilise dans la fenetre. static car on a besoin d'y acceder partout: quand on appuie sur un bouton, quand on lit un fichier, quand on cherche les pere d'union
	static Tableau tabPrincipal;	
	//affichage du score en bas de l'ecran
	private JLabel score;	
	//affichage du tour du joueur en bas de l'ecran
	private JLabel tourJoueur;	
	//affichage des infos des fonctions utilisable dans le menu deroulant en haut de l'ecran
	private JLabel printInfo;	
	 //menu deroulant contenant les fonctions utilisables pendant toute la partie
	private JComboBox<?> listeDeroul;
	private int score1;
	private int score2;
	private Bouton temp;
	private String[] selectedFunc = {"colorerCase","afficherComposante","existeCheminCases","relierComposantes"};
	private String[] infoFunc = {"Cliquer pour colorer la case","Cliquer sur une case de couleur pour afficher les meme cases de sa composante","Cliquer sur deux cases pour savoir si elles sont dans le meme groupe","Cliquer pour voir si la case peut en relier deux autres"};
	private boolean ordi = false;
	
	public Fenetre() {
		super();
		/*----------------------------------------------------VARIABLE-------------------------------------------------*/
		//conteneur de la fenetre auquel on ajoute les jpanel
		Container container = this.getContentPane();
		//taille du tableau
		int n;
		//panneau de jeu
		JPanel jeu = new JPanel();
		//panneau avec le menu deroulant et les infos lie
		JPanel menu = new JPanel();
		//panneau contenant le score et le nombre de tour
		JPanel information = new JPanel();
		
		JPanel affichageScore = new JPanel();
		JPanel affichageTour = new JPanel();
		//contient le score a afficher
		String aAfficher;
		//contient le nombre de tour a afficher
		String tour;
		
		
		if(Main.fileRead) {
			ReadFile read = new ReadFile(new File(Main.FILE));
			try {
				read.remplirGrilleFichier();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}else {
			tabPrincipal = new Tableau(Main.tailleTab,Main.valMax);
			tabPrincipal.remplirGrilleAleatoire();
		}
		
		this.setTitle("Jouer");
		this.setSize(Main.SIZE, Main.SIZE);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(true);
		n = tabPrincipal.getTaille();
		
		//affichage du tableau de jeu
		jeu.setLayout(new GridLayout(n,n));
		for(int i = 0; i <= n-1; i++) {
			for (int j = 0; j <= n-1; j++) {
				//les boutons que l'on ajoutent se mettent n/ligne et a la fin de la ligne, on va la ligne suivante
				jeu.add(tabPrincipal.getTab()[i][j]); 
				tabPrincipal.getTab()[i][j].addActionListener(this);
			}
		}
		
		//affichage du menu deroulant
		listeDeroul = new JComboBox<>(selectedFunc);
		listeDeroul.addActionListener(this);
		printInfo=  new JLabel(infoFunc[listeDeroul.getSelectedIndex()]);
		listeDeroul.setSelectedIndex(0);
		menu.add(listeDeroul);
		menu.add(printInfo);
		
		//affichage du score
		score1 = meilleureComposante(1);
		score2 = meilleureComposante(2);
		aAfficher = "<html><font color='red'>SCORE DU J1 (ROUGE) : </font>" + String.valueOf(score1)+ "	&nbsp &nbsp &nbsp " + "<font color='blue'>SCORE DU J2 (BLEU) : </font>" + String.valueOf(score2) + "<html>";
		this.score = new JLabel(aAfficher);
		affichageScore.add(score);
		String temp = "J" +String.valueOf(PLAYER);
		if (PLAYER == 1) {
			tour = "<html>Tour de <font color='red'>" + temp +"</font><html>";
		}else {
			tour = "<html>Tour de <font color='blue'>" + temp +"</font><html>";
		}
		
		tourJoueur = new JLabel(tour);
		affichageTour.add(tourJoueur);information.add(affichageScore,BorderLayout.EAST);
		information.add(affichageTour,BorderLayout.WEST);
		
		
		
		//organisation de l'affichage
		container.setLayout(new BorderLayout());
		information.setPreferredSize(new Dimension(this.getWidth(), (int)(this.getHeight()*0.05)));
		menu.setPreferredSize(new Dimension(this.getWidth(),(int)(this.getHeight()*0.05)));
		jeu.setPreferredSize(new Dimension(this.getWidth(), (int)(this.getHeight() - this.getHeight()*0.10)));
		container.add(information , BorderLayout.SOUTH);
		container.add(jeu);
		container.add(menu,BorderLayout.NORTH);

		this.setVisible(true);
	}
	
	
	public int meilleureComposante(int joueur) {	//affiche le groupe ayant la plus grosse valeur pour un joueur
		int res = 0;
		int temp;
		//les tab j1/j2 contiennent les pere de chaque union presente dans le tableau
		if (joueur == 1) {
			for (UnionFind f : Fenetre.tabPrincipal.getJ1()) {	
				temp = f.afficherScore();
				if (temp > res) {
					res = temp;
				}
			}
		}
		if (joueur == 2) {
			for (UnionFind f : Fenetre.tabPrincipal.getJ2()) {
				temp = f.afficherScore();
				if (temp > res) {
					res = temp;
				}
			}
		}
		return res;
	}
	
	public void changeOrdi(boolean b) {
		ordi = b;
	}
	
	public void changeScore() {
		String temp, temp2;
		score1 = meilleureComposante(1);
		score2 = meilleureComposante(2);
		temp = "<html><font color='red'>SCORE DU J1 (ROUGE) : </font>" + String.valueOf(score1)+ "	&nbsp &nbsp &nbsp " + "<font color='blue'>SCORE DU J2 (BLEU) : </font>" + String.valueOf(score2) + "<html>";
		score.setText(temp);
		temp = "J" +String.valueOf(PLAYER);
		if (PLAYER == 1) {
			temp2 = "<html>Tour de <font color='red'>" + temp +"</font><html>";
		}else {
			temp2 = "<html>Tour de <font color='blue'>" + temp +"</font><html>";
		}
		tourJoueur.setText(temp2);
	}
	
	public void finDuJeu() {
		String joueur;
		String temp;
		int winnerScore;
		if(meilleureComposante(1) == meilleureComposante(2)) {
			temp = "Egalite, score des deux joueur : " + meilleureComposante(1);
		}else {
			if (meilleureComposante(1) > meilleureComposante(2) ) {
				joueur = "Joueur 1 (Rouge)";
				winnerScore = meilleureComposante(1);
			}else {
				joueur = "Joueur 2 (Bleu)";
				winnerScore = meilleureComposante(2);
			}
			temp = joueur + " a gagne avec un score de " + winnerScore + " points";
		}
		
		score.setText(temp);
		tourJoueur.setText("");
	}
	

	
	public void actionPerformed(ActionEvent arg0) {
		boolean relier = false;
		//affichage des infos de la fonction choisi
		String action = listeDeroul.getSelectedItem().toString();
		String info = infoFunc[listeDeroul.getSelectedIndex()];
		printInfo.setText(info);
		//on va verifier quand on clique sur une case quel action du menu deroulant est actuellement choisi et agir en fonction
		for(int i =0; i <= tabPrincipal.getTaille()-1; i++) {
			for(int j =0; j <= tabPrincipal.getTaille()-1; j++) {
				if (arg0.getSource() == tabPrincipal.getTab()[i][j]) {
					Bouton courant = tabPrincipal.getTab()[i][j];
					if(action == "colorerCase" ) {	//si le menu deroulant est sur la coloration de case
						if (courant.getUnion().getRepresentant().getCouleur() == 0 ) {	//l'action ne se fait que sur une case blanche 
							tabPrincipal.colorerCase(i, j, PLAYER);	
							tabPrincipal.refreshTabJoueur();	
							if (Fenetre.PLAYER == 1) {
								Fenetre.PLAYER = 2;
							}
							else {
								Fenetre.PLAYER = 1;
							}
							changeScore();
							tabPrincipal.tourJoue();
							if(tabPrincipal.getTour() >= (tabPrincipal.getTaille()*tabPrincipal.getTaille())+1) {	//pour un tableau 3*3, le tour 9 est le dernier tour A JOUE donc 10 est la fin de la partie
								//fin du jeu
								finDuJeu();
							} 
							if(ordi) {	//si jeu avec ordi, on appelle son tour de jeu
								try {
									Main.play.jouerOrdiHumain();
								} catch (FileNotFoundException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							if(tabPrincipal.getTour() >= (tabPrincipal.getTaille()*tabPrincipal.getTaille())+1) {
								//fin du jeu
								finDuJeu();
							} 
							//deux test de fin de jeu car cela n'est plus apres la fin du tour d'un joueur mais potentiellement apres le tour de l'ordi
						}
					}
					else if (action == "existeCheminCases") {
						if(temp != null) { //si un premier bouton a ete clique
							if (courant.getUnion().getRepresentant().getCouleur() != 0 && temp.getUnion().getRepresentant().getCouleur() != 0) {
								relier = tabPrincipal.existeCheminCases(courant.getUnion(), temp.getUnion());
								if(relier) {
									info = "<html>" + info + "<br/>Ces cases sont dans la meme composante <html>";
								}else {
									info = "<html>" + info + "<br/>Ces cases ne sont pas dans la meme composante<html>";
								}
								printInfo.setText(info);	
							}
							temp = null;
						}else {
							//sinon on enregistre le premier bouton clique
							if(courant.getUnion().getRepresentant().getCouleur() != 0) {
								info = "<html>" + info + "<br/>Cliquer sur une autre case <html>";
								temp = courant;
								printInfo.setText(info);
							}
						}
					}
					else if (action == "relierComposantes") {
						if(courant.getUnion().getRepresentant().getCouleur() == 0) { 	//l'action ne se fait que sur une case blanche 
							relier = tabPrincipal.relierComposantes(i, j,PLAYER);
							if(relier) {
								info = "<html>" + info + "<br/>Cette case relie deux autres cases adjacentes<html>";
							}else {
								info = "<html>" + info + "<br/>Cette case ne reliera aucune case adjacente<html>";
							}
							printInfo.setText(info);
						}
					}
					else if(action == "afficherComposante") {
						if(courant.getUnion().getRepresentant().getCouleur() != 0) {	//l'action ne se fait que sur une case non blanche 
							courant.afficherComposante();
						}
					}
				}
				this.repaint();	//reactualise graphiquement toute la fenetre
			}
		}
	}
}
