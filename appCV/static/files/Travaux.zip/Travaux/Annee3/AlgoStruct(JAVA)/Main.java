import java.io.FileNotFoundException;

public class Main {
	static int SIZE = 800;
	/*------------------------------VARIABLE A CHANGER POUR MODIFIER LE FONCTIONNEMENT DU JEU------------------------------*/
	static String FILE = "test.txt";	//inserer ici le nom du fichier placer dans le dossier
	static boolean fileRead = false; //true = lire un fichier
	static int tailleTab = 6;	//a changer pour le nombre de case
	static int valMax = 10;		//a changer pour la valeur max d'une case
	static boolean jouerAvecUnOrdi = true;	//a changer pour jouer avec un ordi ou non
	static GestionJeu play = new GestionJeu();
	
	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		
		try {
			if(jouerAvecUnOrdi) {
				play.jouerOrdiHumain();
			}else{
				play.jouerDeuxHumains();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
}
