import java.util.ArrayList;

public class UnionFind {	//une case = une union
	private Case representant;	//case liee a l'union
	private ArrayList<UnionFind> fils;
	private UnionFind parent; //pointeur vers son pere
	//quoi qu'il arrive avec la compression on se retrouve toujours avec un parent qui a plusieurs feuilles.
	
	public UnionFind(Case c) {
		this.representant = c;
		this.fils = new ArrayList<UnionFind>();
		this.parent = null;
	}
	
	
	public Case getRepresentant() {
		return this.representant;
	}
	
	public UnionFind getParent() {
		return this.parent;
	}
	
	public ArrayList<UnionFind> getFils(){
		return fils;
	}
	
	
	
	//uni f dans l'unionfind courante si f n'est pas deja dedans (si case de gauche et case de droite a courant sont la meme composante par ex.)
	public void union(UnionFind f) { 
		if (!this.getFils().contains(f)){
			this.fils.add(f);
			f.setPere(this); 
			compression();
		}
	}
	
	//f devient pere de courant
	public void setPere(UnionFind f) {	
		this.parent = f;
	}
	
	//les fils des fils du pere sont ajoutes comme fils du pere et supprime du reste
	public void compression() {		
		ArrayList<UnionFind> temp = new ArrayList<UnionFind>();
		for (UnionFind f : this.fils) {
			if (!f.getFils().isEmpty()) { 
				for(UnionFind fbis: f.getFils()) {	//on ajoute toute les unions a l'union courante
					temp.add(fbis);
				}
				f.getFils().clear();
			}
		}
		for (UnionFind f : temp) {
			this.union(f);
		}
	}

	//affiche le score de l'union (inclue ses fils)
	public int afficherScore() { 
		int res;
		if(this.getParent() == null) {	//si pas de pere
			res = this.getRepresentant().getValeur();
			for (UnionFind f : this.getFils()) {
				res += f.getRepresentant().getValeur();
			}
		}else {
			res = this.getParent().getRepresentant().getValeur();
			for (UnionFind f : this.getParent().getFils()) {
				res += f.getRepresentant().getValeur();
			}
		}
		return res;
	}
	
	
}
