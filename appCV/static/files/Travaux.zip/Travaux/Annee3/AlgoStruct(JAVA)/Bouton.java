import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;

public class Bouton extends JButton implements MouseListener { //un bouton par case
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UnionFind f;
	
	public Bouton(UnionFind temp) {
		this.f = temp;
		this.addMouseListener(this);
	}
	
	public UnionFind getUnion() {
		return this.f;
	}
	
	public void paintComponent(Graphics g) {
		int screenWidth = this.getWidth();
		int screenHeight = this.getHeight();
		Graphics2D g2d = (Graphics2D)g;
		if(this.getUnion().getRepresentant().getHover()) {	//colorie la case en vert
			g2d.setColor(Color.green);
		}else {
			if(f.getRepresentant().getCouleur() == 1) {
				g2d.setColor(new Color(200,100,100));	//rouge clair
			}
			else if (f.getRepresentant().getCouleur() == 2) {
				g2d.setColor(Color.CYAN);
			}
			else if (f.getRepresentant().getCouleur() == 0){
				g2d.setColor(Color.white);
			}
		}
		g2d.fillRect(0, 0, screenWidth, screenHeight);
		g2d.setColor(Color.BLACK);
		g2d.drawString(String.valueOf(f.getRepresentant().getValeur()),screenWidth/2,screenHeight/2);	//ecrire le score de la case au centre de la case
	}
	
	//affiche les composante en vert qui sont liees a la case sur laquelle on appuie
	public void afficherComposante() {	
		if(this.getUnion().getParent() != null) {	//si la case est le pere de l'union
			this.getUnion().getParent().getRepresentant().hover();
			for(UnionFind f : this.getUnion().getParent().getFils()) {
				f.getRepresentant().hover();
			}
		}else {	//si fils
			this.getUnion().getRepresentant().hover();
			for(UnionFind f : this.getUnion().getFils()) {
				f.getRepresentant().hover();
			}
		}
	}
	

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		//affiche le score d'une composante lorsqu'on laisse la souris sur l'une de ses cases
		if(f.getRepresentant().getCouleur() != 0) {
			if(f.getParent() == null) {
				this.setToolTipText("Score de cette composante : " + String.valueOf(f.afficherScore()));
			}else {
				this.setToolTipText("Score de cette composante : " + String.valueOf(f.getParent().afficherScore()));
			}

		}
		
	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		//enleve la couleur vert des cases lorsqu'on enleve la souris de ces cases
		if(this.getUnion().getRepresentant().getHover()) {
			this.afficherComposante();
			Main.play.jouer.repaint();
		}
	}


	@Override
	public void mousePressed(MouseEvent arg0) {
		
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
