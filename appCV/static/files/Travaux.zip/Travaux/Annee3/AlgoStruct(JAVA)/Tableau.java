import java.util.ArrayList;
import java.util.Random;


public class Tableau {
	private int n; //taille du tableau
	private int nbTour = 1;
	private int k; //nb max present dans le tableau
	private Bouton tableJeu[][];
	private ArrayList<UnionFind> tabJ1; // couleur rouge
	private ArrayList<UnionFind> tabJ2; //couleur bleu
	
	public Tableau(int taille, int max) {
		this.n = taille;
		this.k = max;
		this.tableJeu = new Bouton[n][n];
		this.tabJ1 = new ArrayList<UnionFind>();
		this.tabJ2 = new ArrayList<UnionFind>();
	}
	
	
/*-----------------------------------------------GETTERS---------------------------------------*/
	public ArrayList<UnionFind> getJ1(){
		return tabJ1;
	}
	
	public ArrayList<UnionFind> getJ2(){
		return tabJ2;
	}
	
	public Bouton[][] getTab(){
		return this.tableJeu;
	}
	
	public int getTaille() {
		return this.n;
	}
	
	public int getTour() {
		return nbTour;
	}
	
	public int getValMax() {
		return k;
	}
	
	
	
	
	
	public void tourJoue() {
		nbTour++;
	}
	
	public void changerNbTour(int n) { //utiliser pour la lecture fichier
		nbTour = n;
	}

	public void remplirGrilleAleatoire(){
		Random x = new Random();
		for (int i = 0; i <= n-1; i++) {
			for (int j = 0; j <= n-1; j++) {
				tableJeu[i][j]= new Bouton(new UnionFind (new Case(x.nextInt(k)+1, 0, i, j)));
			}
		}
	}
	
	public void refreshTabJoueur() {	//actualise les unions presentes dans le tableau
		this.tabJ1.clear();
		this.tabJ2.clear();
		//pour chaque case, celle qui sont de couleurs et qui n'ont pas de parents sont ajoutes dans la table associe
		for (int i = 0; i <= this.n-1; i++) {
			for (int j = 0; j <= this.n-1; j++) {
				if(tableJeu[i][j].getUnion().getParent() == null) {	//si la case n'a pas de pere
					if(tableJeu[i][j].getUnion().getRepresentant().getCouleur() == 1) {	//et qu'elle a une couleur
						if(!this.tabJ1.contains(tableJeu[i][j].getUnion())) {
							this.tabJ1.add(this.tableJeu[i][j].getUnion());
						}
					}
					if(tableJeu[i][j].getUnion().getRepresentant().getCouleur() == 2) {	//et qu'elle a une couleur
						if(!this.tabJ2.contains(tableJeu[i][j].getUnion())) {
							this.tabJ2.add(this.tableJeu[i][j].getUnion());
						}
					}
				}
			}			
		}
	}
	
	

	
	
	//colorie la case, unie cette case au adjacente
	public void colorerCase(int x, int y, int c) {
		Bouton courant = tableJeu[x][y];
		courant.getUnion().getRepresentant().changerCouleur(c);
		Fenetre.tabPrincipal.unirCase(x, y, c);
	}

	public boolean relierComposantes(int x, int y, int joueur) {
		//verifie que la case possede au minimun deux case adjacente de meme couleur que le tour du joueur en cours
		boolean first = false;
		boolean second = false;
		if(x > 0) {
			UnionFind gauche = tableJeu[x-1][y].getUnion();
			if(gauche.getRepresentant().getCouleur() == joueur) {
				first = true;
			}
		}
		if(y > 0) {
			UnionFind haut = tableJeu[x][y-1].getUnion();
			if(haut.getRepresentant().getCouleur() == joueur) {
				if(first) {
					second = true;
				}else {
					first = true;
				}
				
			}
			
		}
		if(x < this.n-1) {
			UnionFind droite = tableJeu[x+1][y].getUnion();
			if(droite.getRepresentant().getCouleur() == joueur) {
				if(first) {
					second = true;
				}else {
					first = true;
				}
			}
			
		}
		if(y < this.n-1) {
			UnionFind bas = tableJeu[x][y+1].getUnion();
			if(bas.getRepresentant().getCouleur() == joueur) {
				if(first) {
					second = true;
				}else {
					first = true;
				}
			}
		}
		return (first && second);
	}
	
	
	public boolean existeCheminCases(UnionFind c1, UnionFind c2) {
		if ((c1.getRepresentant().getCouleur() == c2.getRepresentant().getCouleur()) && (c1.getRepresentant().getCouleur() !=0)) {
			return ( (c1.getParent() == c2) || (c2.getParent() == c1) || ((c2.getParent() == c1.getParent()) && (c1.getParent() != null)) );
		}
		return false;
	}
	
	public void unirCase(int x, int y, int joueur) {
		//si des cases adjacentes sont de la meme couleur, elle sont unis a la case courante
		UnionFind courant = this.tableJeu[x][y].getUnion();
	
		if(x > 0) {
			UnionFind gauche = tableJeu[x-1][y].getUnion();
			if ((gauche.getRepresentant().getCouleur() == courant.getRepresentant().getCouleur()) || (gauche.getRepresentant().getCouleur() == joueur)) { 	//bouton de gauche meme couleur
				if(gauche.getParent() != null) {
					courant.union(gauche.getParent());
				}
				else {
					courant.union(gauche);
				}
			}
		}
		if(y > 0) {
			UnionFind haut = tableJeu[x][y-1].getUnion();
			if (haut.getParent() != courant) {
				if ((haut.getRepresentant().getCouleur() == courant.getRepresentant().getCouleur()) || (haut.getRepresentant().getCouleur() == joueur)) { 	//bouton de gauche meme couleur
					if(haut.getParent() != null) {
						courant.union(haut.getParent());
					}
					else {
						courant.union(haut);
					}
				}
			}
			
		}
		if(x < this.n-1) {
			UnionFind droite = tableJeu[x+1][y].getUnion();
			if (droite.getParent() != courant) {
				if ((droite.getRepresentant().getCouleur() == courant.getRepresentant().getCouleur()) || (droite.getRepresentant().getCouleur() == joueur)) { 	//bouton de gauche meme couleur
					if(droite.getParent() != null) {
						courant.union(droite.getParent());
					}
					else {
						courant.union(droite);
					}
				}
			}
			
		}
		if(y < this.n-1) {
			UnionFind bas = tableJeu[x][y+1].getUnion();
			if (bas.getParent() != courant) {
				if ((bas.getRepresentant().getCouleur() == courant.getRepresentant().getCouleur()) || (bas.getRepresentant().getCouleur() == joueur)) { 	//bouton de gauche meme couleur
					if(bas.getParent() != null) {
						courant.union(bas.getParent());
					}
					else {
						courant.union(bas);
					}
				}
			}
			
		}
	}
}
